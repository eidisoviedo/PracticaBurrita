package co.com.prueba_tecnica.util;

public class Constantes {

	public static final float PRECIO_POR_KILOMETRO = 35;
	public static final String DISTANCIA = "Distancia:";
	public static final String DIAS_DE_ESTANCIA = "D�as de estancia";

	private Constantes() {}
}
